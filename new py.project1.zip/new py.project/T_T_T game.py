# Tic-Tac-Toe Game in Python

# Function to print the Tic-Tac-Toe board
def print_board(board):
    print("\n")
    for row in board:
        print(" | ".join(row))
        print("-" * 5)
    print("\n")

# Function to check if a player has won
def check_win(board, player):
    # Check rows, columns, and diagonals
    for row in board:
        if all([spot == player for spot in row]):
            return True
    
    for col in range(3):
        if all([board[row][col] == player for row in range(3)]):
            return True
    
    if board[0][0] == board[1][1] == board[2][2] == player:
        return True
    
    if board[0][2] == board[1][1] == board[2][0] == player:
        return True
    
    return False

# Function to check if the board is full (a tie)
def check_tie(board):
    return all([spot != " " for row in board for spot in row])

# Function to handle the gameplay
def tic_tac_toe():
    # Create a 3x3 board
    board = [[" " for _ in range(3)] for _ in range(3)]
    current_player = "X"  # X will go first
    
    while True:
        print_board(board)
        print(f"Player {current_player}'s turn.")
        
        # Get row and column input from the player
        try:
            row = int(input("Enter the row (1, 2, 3): ")) - 1
            col = int(input("Enter the column (1, 2, 3): ")) - 1
        except ValueError:
            print("Invalid input. Please enter numbers between 1 and 3.")
            continue
        
        # Check if the move is valid
        if row not in range(3) or col not in range(3):
            print("Invalid move. Try again.")
            continue
        if board[row][col] != " ":
            print("Spot already taken. Try again.")
            continue
        
        # Place the player's mark on the board
        board[row][col] = current_player
        
        # Check for a win
        if check_win(board, current_player):
            print_board(board)
            print(f"Player {current_player} wins!")
            break
        
        # Check for a tie
        if check_tie(board):
            print_board(board)
            print("It's a tie!")
            break
        
        # Switch players
        current_player = "O" if current_player == "X" else "X"

# Start the game
tic_tac_toe()
