

# To Do List Program

# Initialize an empty list
todo_list = []

# Function to display the To Do List
def display_todo_list():
	print("To Do List:")
	for i, task in enumerate(todo_list, start=1):
		print(f"{i}. {task}")

# Function to add a task to the To Do List
def add_task():
	task = input("Enter a task: ")
	todo_list.append(task)
	print("Task added!")

# Function to delete a task from the To Do List
def delete_task():
	display_todo_list()
	task_number = int(input("Enter the task number to delete: ")) - 1
	if task_number >= 0 and task_number < len(todo_list):
		del todo_list[task_number]
		print("Task deleted!")
	else:
		print("Invalid task number.")

# Main program loop
while True:
	print("\nTo Do List Options:")
	print("1. Display To Do List")
	print("2. Add Task")
	print("3. Delete Task")
	print("4. Quit")
	choice = input("Enter your choice: ")
	if choice == "1":
		display_todo_list()
	elif choice == "2":
		add_task()
	elif choice == "3":
		delete_task()
	elif choice == "4":
		break
	else:
		print("Invalid choice. Please try again.")

