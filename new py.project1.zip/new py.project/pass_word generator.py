import random
import string

def generate_password(length):
    if length < 6:
        return "Password length should be at least 6 characters."
    
    # Define the character sets
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    special = string.punctuation

    # Ensure password has at least one of each category (lower, upper, digits, special)
    all_characters = lower + upper + digits + special
    password = [
        random.choice(lower),
        random.choice(upper),
        random.choice(digits),
        random.choice(special),
    ]

    # Fill the rest of the password length with random choices from all categories
    password += random.choices(all_characters, k=length - 4)

    # Shuffle to avoid predictable patterns
    random.shuffle(password)

    return ''.join(password)

# Example usage:
password_length = 10
print("Generated Password is:", generate_password(password_length))
